#!/usr/bin/env node


const httpProxy = require('http-proxy');

httpProxy.createProxyServer({
    target: 'http://127.0.0.1:5000'
}).listen(process.env.PORT || 8080);