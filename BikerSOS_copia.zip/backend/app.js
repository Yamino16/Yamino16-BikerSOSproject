require('dotenv').config(); // Carica le variabili dal file .env
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('./db');
const { authenticateToken, SECRET } = require('./middleware');

const app = express(); 
app.use(cors());
app.use(express.json());

// API: Registrazione
app.post('/api/auth/register', async (req, res) => {
    const { email, password } = req.body;
    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = await pool.query(
            'INSERT INTO users (email, password_hash) VALUES ($1, $2) RETURNING id',
            [email, hashedPassword]
        );
        const newProfile = await pool.query(
            'INSERT INTO profiles (user_id) VALUES ($1) RETURNING id',
            [newUser.rows[0].id]
        );
        res.status(201).json({ userId: newUser.rows[0].id, profileId: newProfile.rows[0].id });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// API: Login
app.post('/api/auth/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
        if (user.rows.length === 0) return res.status(404).json({ error: 'Utente non trovato' });

        const validPassword = await bcrypt.compare(password, user.rows[0].password_hash);
        if (!validPassword) return res.status(401).json({ error: 'Password errata' });

        const token = jwt.sign({ id: user.rows[0].id }, SECRET, { expiresIn: '24h' });
        res.json({ token });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// API: Ottieni/Crea Profilo (Dashboard)
app.get('/api/profile', authenticateToken, async (req, res) => {
    try {
        const profile = await pool.query('SELECT * FROM profiles WHERE user_id = $1', [req.user.id]);
        res.json(profile.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.put('/api/profile', authenticateToken, async (req, res) => {
    const { name, dob, photo_url, ice_name, ice_phone, allergies, conditions, medications } = req.body;
    try {
        const updated = await pool.query(
            `UPDATE profiles SET 
                name = $1, dob = $2, photo_url = $3, ice_name = $4, ice_phone = $5, 
                allergies = $6, conditions = $7, medications = $8, updated_at = CURRENT_TIMESTAMP
            WHERE user_id = $9 RETURNING *`,
            [name, dob, photo_url, ice_name, ice_phone, allergies, conditions, medications, req.user.id]
        );
        res.json(updated.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// API: Pagina Emergenza
app.get('/api/emergency/:uuid', async (req, res) => {
    try {
        const profile = await pool.query(
            'SELECT name, dob, photo_url, ice_name, ice_phone, allergies, conditions, medications FROM profiles WHERE id = $1',
            [req.params.uuid]
        );
        if (profile.rows.length === 0) return res.status(404).json({ error: 'Profilo non trovato' });
        res.json(profile.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Rotta di test veloce
app.get('/api/emergency/test', (req, res) => {
    res.json({ status: "ok", message: "IL BACKEND FUNZIONA ED È ONLINE!" });
});

// 🚀 AVVIO DEL SERVER COMPATIBILE CON IONOS E AMBIENTE LOCALE
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Backend in esecuzione sulla porta ${PORT}`);
});

// Esporta l'app: pezzo fondamentale richiesto da Phusion Passenger di IONOS
module.exports = app;