const { Pool } = require('pg');

// La tua stringa ufficiale di Neon come paracadute se il file .env non viene letto
const neonConnectionString = 'postgresql://neondb_owner:npg_6FrnMZCA3IBN@ep-restless-queen-astjs0ne-pooler.c-4.eu-central-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require';

const pool = new Pool({
  // Se esiste process.env.DATABASE_URL usa quello, altrimenti usa la stringa diretta
  connectionString: process.env.DATABASE_URL || neonConnectionString, 
  ssl: {
    rejectUnauthorized: false // Obbligatorio per Neon
  }
});

module.exports = pool;