PHP
<?php
// 1. Configurazione CORS totale per l'applicazione mobile e web
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, Stripe-Signature");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

// 2. Credenziali Database Neon & Chiavi
define('DB_HOST', 'HIDDEN_FOR_SECURITYh');
define('DB_PORT', 'HIDDEN_FOR_SECURITY');
define('DB_NAME', 'HIDDEN_FOR_SECURITY');
define('DB_USER', 'HIDDEN_FOR_SECURITY');
define('DB_PASS', 'HIDDEN_FOR_SECURITY);
define('JWT_SECRET', 'HIDDEN_FOR_SECURITY');

// 💳 CHIAVI STRIPE LIVE
define('STRIPE_SECRET_KEY', 'HIDDEN_FOR_SECURITY'); 
define('STRIPE_WEBHOOK_SECRET', 'HIDDEN_FOR_SECURITY');

// 📧 CONFIGURAZIONE SMTP UFFICIALE IONOS AUTENTICATO
define('SMTP_EMAIL', 'contatti@bikersos.it'); 
define('SMTP_PASSWORD', 'HIDDEN_FOR_SECURITY'); 

// ==========================================
// 🚀 MOTORE EMAIL PREMIUM (Design stile Apple/Tesla)
// ==========================================
function sendPremiumEmail($to, $subject, $title, $messageHtml, $buttonText = '', $buttonUrl = '') {
    $html = '
    <!DOCTYPE html>
    <html>
    <head><meta charset="UTF-8"></head>
    <body style="margin: 0; padding: 40px 20px; background-color: #050505; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif;">
        <table width="100%" cellpadding="0" cellspacing="0" style="max-width: 600px; margin: 0 auto; background-color: #0a0a0a; border: 1px solid #1a1a1a; border-radius: 16px; overflow: hidden;">
            <tr>
                <td style="padding: 40px; text-align: center; border-bottom: 1px solid #1a1a1a; background: linear-gradient(180deg, #111111 0%, #0a0a0a 100%);">
                    <h1 style="color: #ffffff; margin: 0; font-size: 32px; font-weight: 900; font-style: italic; letter-spacing: -1px;">Biker<span style="color: #FF1E1E;">SOS</span></h1>
                </td>
            </tr>
            <tr>
                <td style="padding: 40px;">
                    <h2 style="color: #ffffff; margin: 0 0 20px 0; font-size: 22px; font-weight: 700; letter-spacing: -0.5px;">'.$title.'</h2>
                    <div style="color: #a1a1aa; font-size: 15px; line-height: 1.6; margin-bottom: 35px;">'.$messageHtml.'</div>';
    
    if ($buttonText && $buttonUrl) {
        $html .= '<div style="text-align: center;">
                    <a href="'.$buttonUrl.'" style="display: inline-block; background-color: #FF1E1E; color: #ffffff; text-decoration: none; padding: 16px 36px; border-radius: 12px; font-weight: 800; font-size: 14px; letter-spacing: 1.5px; text-transform: uppercase;">'.$buttonText.'</a>
                  </div>';
    }

    $html .= '
                </td>
            </tr>
            <tr>
                <td style="padding: 30px; text-align: center; background-color: #050505; border-top: 1px solid #1a1a1a;">
                    <p style="color: #52525b; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; margin: 0;">Crittografia End-to-End V2.0</p>
                    <p style="color: #3f3f46; font-size: 11px; margin: 10px 0 0 0;">&copy; '.date("Y").' BikerSOS. Questo è un messaggio automatico, non rispondere.</p>
                </td>
            </tr>
        </table>
    </body>
    </html>';

    try {
        $smtpHost = "smtp.ionos.it";
        $smtpPort = 465;
        $socket = fsockopen("ssl://" . $smtpHost, $smtpPort, $errno, $errstr, 15);
        if ($socket) {
            fgets($socket, 515);
            fputs($socket, "EHLO " . $_SERVER['SERVER_NAME'] . "\r\n"); fgets($socket, 515);
            fputs($socket, "AUTH LOGIN\r\n"); fgets($socket, 515);
            fputs($socket, base64_encode(SMTP_EMAIL) . "\r\n"); fgets($socket, 515);
            fputs($socket, base64_encode(SMTP_PASSWORD) . "\r\n"); fgets($socket, 515);
            fputs($socket, "MAIL FROM: <" . SMTP_EMAIL . ">\r\n"); fgets($socket, 515);
            fputs($socket, "RCPT TO: <" . $to . ">\r\n"); fgets($socket, 515);
            fputs($socket, "DATA\r\n"); fgets($socket, 515);
            
            $headers = "From: BikerSOS <" . SMTP_EMAIL . ">\r\n" .
                       "To: <" . $to . ">\r\n" .
                       "Subject: " . $subject . "\r\n" .
                       "MIME-Version: 1.0\r\n" .
                       "Content-Type: text/html; charset=UTF-8\r\n" .
                       "Content-Transfer-Encoding: 8bit\r\n\r\n";
                       
            fputs($socket, $headers . $html . "\r\n.\r\n"); fgets($socket, 515);
            fputs($socket, "QUIT\r\n"); fclose($socket);
        }
    } catch (Exception $e) { error_log("Errore SMTP: " . $e->getMessage()); }
}

// Connessione nativa a PostgreSQL
function getDB() {
    $conn_string = "pgsql:host=" . DB_HOST . " port=" . DB_PORT . " dbname=" . DB_NAME . " user=" . DB_USER . " password=" . DB_PASS . " sslmode=require";
    try {
        $db = new PDO($conn_string);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $db;
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(["error" => "Errore DB: " . $e->getMessage()]); exit;
    }
}

// Middleware di autenticazione JWT
function authenticateToken() {
    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    if (empty($authHeader) || !preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
        http_response_code(401); echo json_encode(["error" => "Token mancante"]); exit;
    }
    $token = $matches[1];
    $parti = explode('.', $token);
    if (count($parti) !== 3) { http_response_code(403); echo json_encode(["error" => "Token corrotto"]); exit; }
    $payload = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $parti[1])), true);
    if (!$payload || !isset($payload['id'])) { http_response_code(403); echo json_encode(["error" => "Token invalido"]); exit; }
    return $payload;
}

// 3. Router
$request_uri = $_SERVER['REQUEST_URI'];
$path = parse_url($request_uri, PHP_URL_PATH);
$path = str_replace('/index.php', '', $path);
$method = $_SERVER['REQUEST_METHOD'];
$body = json_decode(file_get_contents('php://input'), true);

// ==========================================
// ROTTA 0: STRIPE WEBHOOK (POST /api/webhook)
// ==========================================
if ($method === 'POST' && $path === '/api/webhook') {
    $payload = file_get_contents('php://input');
    $sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';
    $sigs = explode(',', $sig_header);
    $timestamp = ''; $signatures = [];
    foreach ($sigs as $sig) {
        list($key, $value) = explode('=', $sig, 2);
        if ($key === 't') $timestamp = $value;
        if ($key === 'v1') $signatures[] = $value;
    }

    $signed_payload = $timestamp . '.' . $payload;
    $expected_signature = hash_hmac('sha256', $signed_payload, STRIPE_WEBHOOK_SECRET);

    if (!in_array($expected_signature, $signatures)) {
        http_response_code(400); exit('Firma Stripe non valida');
    }

    $event = json_decode($payload, true);

    if ($event['type'] === 'checkout.session.completed') {
        $session = $event['data']['object'];

        $userId = $session['client_reference_id'] ?? null;
        $stripeSessionId = $session['id'];
        $customerEmail = $session['customer_details']['email'] ?? 'N/D';
        $total = $session['amount_total'];
        
        $shipping = $session['shipping_details'] ?? $session['customer_details'] ?? null;
        $name = $session['shipping_details']['name'] ?? $session['customer_details']['name'] ?? 'N/D';
        $address = $shipping['address']['line1'] ?? 'N/D';
        $city = $shipping['address']['city'] ?? 'N/D';
        $postalCode = $shipping['address']['postal_code'] ?? 'N/D';
        $country = $shipping['address']['country'] ?? 'N/D';

        try {
            $db = getDB();
            $stmt = $db->prepare('INSERT INTO orders (user_id, stripe_session_id, customer_email, shipping_name, shipping_address, shipping_city, shipping_postal_code, shipping_country, amount_total) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $stmt->execute([$userId, $stripeSessionId, $customerEmail, $name, $address, $city, $postalCode, $country, $total]);
            
            // 🚀 EMAIL 2: CONFERMA ORDINE
            if ($customerEmail !== 'N/D') {
                $prezzoFormattato = number_format($total / 100, 2, ',', '.');
                $ordineHtml = "
                    Abbiamo ricevuto il tuo ordine e stiamo configurando il tuo hardware ufficiale.<br><br>
                    <div style='background-color: #111111; border: 1px solid #222222; border-radius: 12px; padding: 20px; margin-top: 20px; text-align: left;'>
                        <p style='color: #52525b; font-size: 11px; text-transform: uppercase; font-weight: 800; letter-spacing: 1px; margin: 0 0 5px 0;'>Totale Pagato</p>
                        <p style='color: #ffffff; font-size: 28px; font-weight: 900; margin: 0 0 20px 0;'>&euro;{$prezzoFormattato}</p>
                        <p style='color: #52525b; font-size: 11px; text-transform: uppercase; font-weight: 800; letter-spacing: 1px; margin: 0 0 5px 0;'>Indirizzo di Consegna</p>
                        <p style='color: #e4e4e7; font-size: 14px; margin: 0; line-height: 1.5;'><strong>{$name}</strong><br>{$address}<br>{$postalCode} {$city} ({$country})</p>
                    </div><br>
                    Ti avviseremo non appena il pacco verrà affidato al corriere espresso.";
                    
                sendPremiumEmail($customerEmail, "Conferma Ordine - BikerSOS", "Ordine Confermato.", $ordineHtml, "Traccia Spedizione", "https://bikersos.it/ordini");
            }

        } catch (Exception $e) { error_log("Errore ordine Webhook: " . $e->getMessage()); }
    }
    http_response_code(200); echo json_encode(["received" => true]); exit;
}

// ==========================================
// ROTTA: CREA CHECKOUT STRIPE (POST /api/create-checkout)
// ==========================================
if ($method === 'POST' && $path === '/api/create-checkout') {
    $user = authenticateToken();
    $stripe_data = [
        'payment_method_types' => ['card'],
        'mode' => 'payment',
        'client_reference_id' => $user['id'],
        'success_url' => 'https://bikersos.it/ordini?payment=success',
        'cancel_url' => 'https://bikersos.it/vetrina',
        'line_items' => [['price_data' => ['currency' => 'eur', 'product_data' => ['name' => 'Bracciale NFC BikerSOS'], 'unit_amount' => 1590], 'quantity' => 1]],
        'shipping_address_collection' => ['allowed_countries' => ['IT', 'CH', 'FR', 'DE', 'ES']]
    ];

    $ch = curl_init('https://api.stripe.com/v1/checkout/sessions');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERPWD, STRIPE_SECRET_KEY . ':');
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($stripe_data));
    $response = curl_exec($ch); $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);

    if ($http_code === 200) { $result = json_decode($response, true); echo json_encode(["url" => $result['url']]); } 
    else { http_response_code(500); echo json_encode(["error" => "Errore Stripe"]); }
    exit;
}

// ==========================================
// ROTTA: REGISTRAZIONE CON EMAIL (POST /api/auth/register)
// ==========================================
if ($method === 'POST' && $path === '/api/auth/register') {
    $email = $body['email'] ?? ''; $password = $body['password'] ?? ''; $name = $body['name'] ?? '';
    if (empty($email) || empty($password)) { http_response_code(400); echo json_encode(["error" => "Email e password obbligatorie"]); exit; }

    $db = getDB();
    try {
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);
        $stmt = $db->prepare('INSERT INTO users (email, password_hash) VALUES (:email, :pass) RETURNING id');
        $stmt->execute(['email' => $email, 'pass' => $hashedPassword]);
        $userId = $stmt->fetch(PDO::FETCH_ASSOC)['id'];

        $uuid = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x', mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0x0fff) | 0x4000, mt_rand(0, 0x3fff) | 0x8000, mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff));

        $stmtProfile = $db->prepare('INSERT INTO profiles (id, user_id, name) VALUES (:id, :user_id, :name) RETURNING id');
        $stmtProfile->execute(['id' => $uuid, 'user_id' => $userId, 'name' => $name]);
        $profileId = $stmtProfile->fetch(PDO::FETCH_ASSOC)['id'];

        $header = base64_encode(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
        $payload = base64_encode(json_encode(['id' => $userId, 'exp' => time() + 86400]));
        $signature = base64_encode(hash_hmac('sha256', "$header.$payload", JWT_SECRET, true));
        $token = str_replace(['+', '/', '='], ['-', '_', ''], "$header.$payload.$signature");

        // Risposta istantanea per non far attendere l'utente
        ob_start();
        http_response_code(201);
        echo json_encode(["token" => $token, "userId" => $userId, "profileId" => $profileId]);
        header("Connection: close"); header("Content-Length: " . ob_get_length());
        ob_end_flush(); @ob_end_clean();
        if (function_exists('fastcgi_finish_request')) fastcgi_finish_request();

        // 🚀 EMAIL 1: BENVENUTO E ONBOARDING
        $welcomeHtml = "
            La tua registrazione è andata a buon fine.<br><br>
            Ora fai parte dell'infrastruttura BikerSOS. Il tuo account è attivo e pronto per essere configurato con i tuoi dati salvavita.<br><br>
            Accedi subito alla tua <strong>Dashboard Medica</strong> per inserire il tuo gruppo sanguigno, eventuali allergie e i contatti telefonici ICE da chiamare in caso di emergenza.";
        sendPremiumEmail($email, "Benvenuto in BikerSOS", "Benvenuto a bordo, Pilota.", $welcomeHtml, "Configura Dashboard", "https://bikersos.it/dashboard");
        exit;

    } catch (Exception $e) { http_response_code(500); echo json_encode(["error" => "Errore: " . $e->getMessage()]); exit; }
}

// ==========================================
// ROTTA: LOGIN (POST /api/auth/login)
// ==========================================
if ($method === 'POST' && $path === '/api/auth/login') {
    $email = $body['email'] ?? ''; $password = $body['password'] ?? '';
    $db = getDB(); $stmt = $db->prepare('SELECT * FROM users WHERE email = :email'); $stmt->execute(['email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || !password_verify($password, $user['password_hash'])) { http_response_code(401); echo json_encode(["error" => "Credenziali errate"]); exit; }
    $header = base64_encode(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
    $payload = base64_encode(json_encode(['id' => $user['id'], 'exp' => time() + 86400]));
    $signature = base64_encode(hash_hmac('sha256', "$header.$payload", JWT_SECRET, true));
    $token = str_replace(['+', '/', '='], ['-', '_', ''], "$header.$payload.$signature");
    echo json_encode(["token" => $token]); exit;
}

// ==========================================
// ROTTA: OTTIENI PROFILO (GET /api/profile)
// ==========================================
if ($method === 'GET' && $path === '/api/profile') {
    $user = authenticateToken(); $db = getDB();
    $stmt = $db->prepare('SELECT * FROM profiles WHERE user_id = :user_id'); $stmt->execute(['user_id' => $user['id']]);
    echo json_encode($stmt->fetch(PDO::FETCH_ASSOC)); exit;
}

// ==========================================
// ROTTA: AGGIORNA PROFILO (PUT /api/profile)
// ==========================================
if ($method === 'PUT' && $path === '/api/profile') {
    $user = authenticateToken(); $db = getDB();
    $blood = $body['blood_type'] ?? null; if ($blood && str_ends_with($blood, ' ')) $blood = str_replace(' ', '+', $blood);
    try {
        $stmt = $db->prepare("UPDATE profiles SET name = :name, dob = :dob, photo_url = :photo_url, blood_type = :blood_type, ice_name = :ice_name, ice_phone = :ice_phone, allergies = :allergies, conditions = :conditions, medications = :medications, updated_at = CURRENT_TIMESTAMP WHERE user_id = :user_id RETURNING *");
        $stmt->execute(['name' => $body['name'] ?? null, 'dob' => $body['dob'] ?? null, 'photo_url' => $body['photo_url'] ?? null, 'blood_type' => $blood, 'ice_name' => $body['ice_name'] ?? null, 'ice_phone' => $body['ice_phone'] ?? null, 'allergies' => $body['allergies'] ?? null, 'conditions' => $body['conditions'] ?? null, 'medications' => $body['medications'] ?? null, 'user_id' => $user['id']]);
        echo json_encode($stmt->fetch(PDO::FETCH_ASSOC));
    } catch (Exception $e) { http_response_code(500); echo json_encode(["error" => $e->getMessage()]); }
    exit;
}

// ==========================================
// ROTTA: PAGINA EMERGENZA (GET /api/emergency/:uuid)
// ==========================================
if ($method === 'GET' && preg_match('/^\/api\/emergency\/([a-f0-9\-]{36})$/i', $path, $matches)) {
    $uuid = $matches[1]; $db = getDB();
    $stmt = $db->prepare('SELECT * FROM profiles WHERE id = :id'); $stmt->execute(['id' => $uuid]);
    $profile = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$profile) { http_response_code(404); echo json_encode(["error" => "Profilo non trovato"]); exit; }
    echo json_encode($profile); exit;
}

// ==========================================
// ROTTA: OTTIENI ORDINI (GET /api/orders)
// ==========================================
if ($method === 'GET' && $path === '/api/orders') {
    $user = authenticateToken(); $db = getDB();
    try {
        $stmt = $db->prepare('SELECT * FROM orders WHERE user_id = :user_id ORDER BY created_at DESC'); $stmt->execute(['user_id' => $user['id']]);
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC); echo json_encode($orders);
    } catch (Exception $e) { http_response_code(500); echo json_encode(["error" => $e->getMessage()]); }
    exit;
}

// ==========================================
// ROTTA: PASSWORD DIMENTICATA (POST /api/forgot-password)
// ==========================================
if ($method === 'POST' && $path === '/api/forgot-password') {
    $email = $body['email'] ?? '';
    if (empty($email)) { http_response_code(400); echo json_encode(["error" => "Email obbligatoria"]); exit; }
    
    $db = getDB(); $stmt = $db->prepare('SELECT id FROM users WHERE email = :email'); $stmt->execute(['email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    ob_start(); echo json_encode(["message" => "Operazione presa in carico."]);
    header("Connection: close"); header("Content-Length: " . ob_get_length());
    ob_end_flush(); @ob_end_clean(); if (function_exists('fastcgi_finish_request')) fastcgi_finish_request();

    if ($user) {
        $headerSafe = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode(json_encode(['alg' => 'HS256', 'typ' => 'JWT'])));
        $payloadSafe = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode(json_encode(['id' => $user['id'], 'action' => 'reset', 'exp' => time() + 900]))); 
        $signatureSafe = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode(hash_hmac('sha256', "$headerSafe.$payloadSafe", JWT_SECRET, true)));
        $resetToken = "$headerSafe.$payloadSafe.$signatureSafe";

        $resetLink = "https://bikersos.it/login/reset?token=" . $resetToken;
        
        // 🚀 EMAIL 3: RECUPERO PASSWORD GRAFICA
        $resetHtml = "Hai richiesto di reimpostare la password del tuo account. Clicca sul pulsante qui sotto per inserire una nuova chiave di sicurezza. <br><br>Se non hai richiesto questa operazione, puoi tranquillamente ignorare questa email.";
        sendPremiumEmail($email, "Richiesta di Ripristino Password", "Ripristina Accesso.", $resetHtml, "Reimposta Password", $resetLink);
    }
    exit;
}

// ==========================================
// ROTTA: SALVATAGGIO NUOVA PASSWORD (POST /api/reset-password)
// ==========================================
if ($method === 'POST' && $path === '/api/reset-password') {
    $token = $body['token'] ?? ''; $newPassword = $body['password'] ?? '';
    if (empty($token) || empty($newPassword)) { http_response_code(400); echo json_encode(["error" => "Dati mancanti"]); exit; }
    $parti = explode('.', $token); if (count($parti) !== 3) { http_response_code(400); echo json_encode(["error" => "Token non valido"]); exit; }

    $headerEncoded = $parti[0]; $payloadEncoded = $parti[1]; $signatureObj = $parti[2];
    $expectedSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode(hash_hmac('sha256', "$headerEncoded.$payloadEncoded", JWT_SECRET, true)));
    $payload = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $payloadEncoded)), true);
    
    if ($signatureObj !== $expectedSignature || !isset($payload['id']) || $payload['action'] !== 'reset' || $payload['exp'] < time()) {
        http_response_code(400); echo json_encode(["error" => "Link di ripristino scaduto o non valido."]); exit;
    }

    $db = getDB(); $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => 10]);
    $stmt = $db->prepare('UPDATE users SET password_hash = :pass WHERE id = :id');
    $stmt->execute(['pass' => $hashedPassword, 'id' => $payload['id']]);
    echo json_encode(["message" => "Password aggiornata con successo!"]); exit;
}

http_response_code(404); echo json_encode(["error" => "Endpoint non trovato", "path" => $path]);
?>