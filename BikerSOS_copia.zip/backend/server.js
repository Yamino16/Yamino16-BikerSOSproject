const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('./db');
const { authenticateToken, SECRET } = require('./middleware');
const crypto = require('crypto');

// 🔑 CAMBIA QUESTA CON LA TUA CHIAVE SEGRETA REALE DI STRIPE (Live o Test)
// Cerca questa riga in alto nel tuo server.js e incollaci la chiave sk_live:
const stripe = require('stripe')('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');
// 🔑 CHIAVE DEL WEBHOOK (La otterrai nel punto 4 di questa guida)
const endpointSecret = "whsec_... METTI_QUI_IL_TUO_WEBHOOK_SECRET"; 

const app = express();

// CORREZIONE CRITICA PER STRIPE: Il webhook ha bisogno del body grezzo (raw), NON in formato JSON.
// Mettiamo questa rotta PRIMA di app.use(express.json()) altrimenti Stripe fallirà la verifica.
app.post('/api/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
    const sig = req.headers['stripe-signature'];
    let event;

    try {
        event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);
    } catch (err) {
        console.error(`❌ Errore verifica Webhook: ${err.message}`);
        return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    // Intercettiamo l'evento di pagamento completato con successo
    if (event.type === 'checkout.session.completed') {
        const session = event.data.object;

        const userId = session.client_reference_id; // Recuperiamo l'ID utente che ha comprato
        const stripeSessionId = session.id;
        const customerEmail = session.customer_details.email;
        const total = session.amount_total;
        
        // Estraiamo i dati di spedizione inseriti dall'utente su Stripe
        const shipping = session.shipping_details;
        const name = shipping ? shipping.name : 'N/D';
        const address = shipping && shipping.address ? shipping.address.line1 : 'N/D';
        const city = shipping && shipping.address ? shipping.address.city : 'N/D';
        const postalCode = shipping && shipping.address ? shipping.address.postal_code : 'N/D';
        const country = shipping && shipping.address ? shipping.address.country : 'N/D';

        try {
            // Salviamo l'ordine nel Database Neon
            await pool.query(
                `INSERT INTO orders 
                (user_id, stripe_session_id, customer_email, shipping_name, shipping_address, shipping_city, shipping_postal_code, shipping_country, amount_total) 
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
                [userId, stripeSessionId, customerEmail, name, address, city, postalCode, country, total]
            );
            console.log(`💾 [PRODUZIONE] Ordine salvato correttamente per l'utente ID: ${userId}`);
        } catch (dbErr) {
            console.error("❌ Errore nel salvataggio dell'ordine nel DB:", dbErr.message);
        }
    }

    res.json({ received: true });
});

// Ora possiamo caricare i middleware standard per tutte le altre rotte
app.use(cors());
app.use(express.json());

// API: Registrazione
app.post('/api/auth/register', async (req, res) => {
    const { email, password } = req.body;
    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = await pool.query('INSERT INTO users (email, password_hash) VALUES ($1, $2) RETURNING id', [email, hashedPassword]);
        const generatedUuid = crypto.randomUUID();
        const newProfile = await pool.query('INSERT INTO profiles (id, user_id) VALUES ($1, $2) RETURNING id', [generatedUuid, newUser.rows[0].id]);
        res.status(201).json({ userId: newUser.rows[0].id, profileId: newProfile.rows[0].id });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// API: Login
app.post('/api/auth/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
        if (user.rows.length === 0) return res.status(404).json({ error: 'Utente non trovato' });
        const validPassword = await bcrypt.compare(password, user.rows[0].password_hash);
        if (!validPassword) return res.status(401).json({ error: 'Password errata' });
        const token = jwt.sign({ id: user.rows[0].id }, SECRET, { expiresIn: '24h' });
        res.json({ token });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// API: Ottieni Profilo
app.get('/api/profile', authenticateToken, async (req, res) => {
    try {
        const profile = await pool.query('SELECT * FROM profiles WHERE user_id = $1', [req.user.id]);
        res.json(profile.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// API: Aggiorna Profilo
app.put('/api/profile', authenticateToken, async (req, res) => {
    let { name, dob, photo_url, blood_type, ice_name, ice_phone, allergies, conditions, medications } = req.body;
    if (blood_type && typeof blood_type === 'string' && blood_type.endsWith(' ')) {
        blood_type = blood_type.replace(' ', '+');
    }
    try {
        const updated = await pool.query(
            `UPDATE profiles SET name = $1, dob = $2, photo_url = $3, blood_type = $4::varchar, ice_name = $5, ice_phone = $6, allergies = $7, conditions = $8, medications = $9, updated_at = CURRENT_TIMESTAMP WHERE user_id = $10 RETURNING *`,
            [name, dob, photo_url, blood_type, ice_name, ice_phone, allergies, conditions, medications, req.user.id]
        );
        res.json(updated.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// API: Pagina Emergenza (Pubblica)
app.get('/api/emergency/:uuid', async (req, res) => {
    try {
        const profile = await pool.query('SELECT * FROM profiles WHERE id = $1', [req.params.uuid]);
        if (profile.rows.length === 0) return res.status(404).json({ error: 'Profilo non trovato' });
        res.json(profile.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// API: CREAZIONE CHECKOUT STRIPE (REALE E TRACCIATO)
app.post('/api/create-checkout', authenticateToken, async (req, res) => {
    try {
        const session = await stripe.checkout.sessions.create({
            payment_method_types: ['card', 'paypal'],
            // 🚨 DETTAGLIO FONDAMENTALE: Lega l'ID dell'utente loggato a questa transazione Stripe
            client_reference_id: req.user.id, 
            // 🚨 ABILITA L'INSERIMENTO DELL'INDIRIZZO DI SPEDIZIONE SU STRIPE
            shipping_address_collection: {
                allowed_countries: ['IT', 'CH', 'FR', 'DE', 'ES'], // Aggiungi i paesi in cui spedisci
            },
            line_items: [{
                price_data: {
                    currency: 'eur',
                    product_data: { 
                        name: 'Bracciale NFC BikerSOS',
                        description: 'Bracciale salvavita in silicone con chip NFC integrato.',
                    },
                    unit_amount: 1599, // 15,99€
                },
                quantity: 1,
            }],
            mode: 'payment',
            success_url: 'https://bikersos.it/dashboard?payment=success', 
            cancel_url: 'https://bikersos.it/vetrina',
        });
        
        res.json({ url: session.url });
    } catch (err) {
        console.error("Errore Stripe:", err);
        res.status(500).json({ error: err.message });
    }
});

const PORT = 5000;
app.listen(PORT, '127.0.0.1', () => {
    console.log(`Backend in esecuzione su http://localhost:${PORT}`);
});